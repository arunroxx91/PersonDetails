package com.person.details.proto.java;

import java.util.Map;

import com.person.details.proto.java.PersonDetailsBean.PersonDetails;


public class Adapter {
	public void close() {}
    public void configure(Map<String,?> configs, boolean isKey) {}
	public byte[] serialize(String topic, PersonDetails detailsBean) {
		// TODO Auto-generated method stub
		return null;
	}
	public PersonDetails deserialize(String topic, byte[] detailsArray) {
		// TODO Auto-generated method stub
		return null;
	}
}